import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.util.*;
public class FileIO_c17am1 {
	public static void main(String[] args)
	{

/**
 * 
 * Dalton File IO
 * @author A. Milich
 * Date: May 2016
 * 
 *  10 functions completed, only the first one prints to new.html (Mr. Campbell said it was ok to do just one)
 *  new.html formatted when opened using in line styling
 *  
 */
		try{
			File data = new File("/Users/student/Desktop/student_data_good.txt");
			Path studentfile = Paths.get("/Users/student/Desktop/student_data_good.txt");
			BufferedReader reader =  Files.newBufferedReader(studentfile, StandardCharsets.UTF_8);

			Scanner file = new Scanner(data);
			ArrayList<Student> students = new ArrayList<Student>();
			file.nextLine();

			File output =new File("/Users/student/Desktop/new.html"); // output location
			if(!output.exists()){
				output.createNewFile();
			}

			FileWriter fw = new FileWriter(output);
			BufferedWriter bw = new BufferedWriter(fw);


			int counter = 0;
			String line;
			try{
				while( (line = file.nextLine()) !=null)
				{
					students.add(new Student(line));

				}
			}
			catch(NoSuchElementException e){

			}
			boolean stop = false;
			Scanner input = new Scanner(System.in);
			while(stop == false)
			{
				try{ Thread.sleep(10);
				}
				catch(InterruptedException ex){
					Thread.currentThread().interrupt();
				}
				
				//print menu

				System.out.println("Menu:");
				System.out.println("Press 1 to match a last name.");
				System.out.println("Press 2 to see if there are twins.");
				System.out.println("Press 3 to find all of the students with the same birth month.");
				System.out.println("Press 4 to find all students of a specific house.");
				System.out.println("Press 5 to sort students by last name.");
				System.out.println("Press 6 to tally the amount of males and females.");
				System.out.println("Press 7 to compare the number of students in 2 grades");
				System.out.println("Press 8 to find all of the students born in 2001.");
				System.out.println("Press 9 to find first name frequency.");
				System.out.println("Press 10 to find all students that entered in a certain grade.");


				int choice = input.nextInt();

				//MatchLastName
				if(choice == 1)
				{
					Write("Match Last Name Data <br>", bw);
					MatchLastName(students);

				}
				//Twins
				if(choice == 2)
				{
					Write("Twins Data <br>", bw);
					Twins(students,bw);

				}
				//SameBirthMonth
				if(choice == 3)
				{
					Write("Same Birth Month Data <br>", bw);
					SameBirthMonth(students, bw);

				}
				//Same House
				if(choice == 4)
				{
					Write("Same House Data <br>", bw);
					SimilarHouse(students, bw);

				}
				//SortedByLastName
				if(choice == 5)
				{
					Write("Sorted By Last Name Data <br>", bw);
					SortedByLastName(students, bw);


				}
				//NumberOfMalesAndFemales
				if(choice == 6)
				{
					Write("Number Of Males and Females Data <br>", bw);
					NumberOfMalesAndFemales(students, bw);

				}
				
				//WhichGradeIn (compare students in 2 grades)
				if(choice ==7){
					Write("Which Grade Entered Data <br>", bw);
					WhichGradeIn(students,bw);
				}

				//StudentsBornIn2001
				if(choice == 8)
				{
					Write("Sundetns Born in a certain Grade Data <br>", bw);
					StudentsBornIn2001(students, bw);

				}
				//FirstNameFrequency
				if(choice == 9)
				{
					Write("First Name Frequency Data <br>", bw);
					FirstNameFrequency(students, bw);

				}
				//StudentsByGrade
				 if(choice == 10)
				      {
				        Write("Students by Grade <br>", bw);
				        StudentsByGrade(students, bw);
				        
				      }
				//write to new.html
				System.out.println();
				Write("<br>", bw);
			}
			System.out.println("Thank You!");
			Write("Thank You For Using! <br>", bw);
			bw.flush();
			bw.close();

		}
		catch(IOException e){
			System.out.println(e);

		}



	}

	/**
	 * 
	 * @param student
	 * 
	 * **ONLY ONE THAT FORMATS TO HTML FILE, MR. CAMBELL SAID IT WAS OK TO ONLY DO ONE
	 * 
	 * 1) Search student by last name and prints data to new.html on desktop
	 */

	public static void MatchLastName(ArrayList<Student> student)
	{
		try
		{
			BufferedWriter buff = new BufferedWriter(new FileWriter("/Users/student/Desktop/new.html"));
			String writeout = "";

			buff.write("<HTML>");
			buff.write("<body>");
			buff.write("<title>");
			buff.write("Dalton File IO");
			buff.write("</title>");


			buff.write("<div align = 'center'>");
			buff.write("<img src = '/Users/student/Desktop/Dalton_Seal_Large.png'; alt='4/ id = 6/>'; align='middle'; style='width:200px;height:200px;'");
			buff.write("<br>");
			buff.write("<h1>");
			buff.write("Dalton Student Menu");
			buff.write("<br>");
			buff.write("Go Forth Unafraid... and search!");
			buff.write("<br>");
			buff.write("</h1>");
			buff.write("</div>");


			buff.write("<h2>");
			buff.write("Student Search:");
			buff.write("</h2>");


			System.out.println("Please enter in the last name of the student you would like to find");
			System.out.println("Please make sure that the first letter of the last name is capitalized");
			Scanner read = new Scanner(System.in);
			String lastName = read.nextLine();

			for(int i = 0; i<student.size();i++)
			{
				if(student.get(i).getLastName().contains(lastName) == true)
				{


					buff.write("<p style=font-size:120%; color:blue>");
					System.out.println(student.get(i).getFirstName() +" "+student.get(i).getMiddleName() + " " + student.get(i).getLastName() + " " + student.get(i).getSexCode() + " " + student.get(i).getGradeEntered() + " " + student.get(i).getCurrentGrade() + " "+ student.get(i).getClassYear() + " "+ student.get(i).getBirthDay() + " "+student.get(i).getBirthMonth() + " " + student.get(i).getBirthYear() + " "+ student.get(i).getAdvisorName());
					Write(student.get(i).getFirstName() +" "+student.get(i).getMiddleName() + " " + student.get(i).getLastName() + " " + student.get(i).getSexCode() + " " + student.get(i).getGradeEntered() + " " + student.get(i).getCurrentGrade() + " "+ student.get(i).getClassYear() + " "+ student.get(i).getBirthDay() + " "+student.get(i).getBirthMonth() + " " + student.get(i).getBirthYear() + " "+ student.get(i).getAdvisorName() + "<br>", buff);
					buff.write("</p>");

				}

			}
			buff.write("</body>");
			buff.write("</HTML>");

			buff.flush();



		}//try

		catch (Exception e)
		{
			System.out.println("there was problem!");
			System.out.println(e);
		}

	}	  
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 2) Uses collections to return the twins in the data set
	 */
	public static void Twins(ArrayList<Student> student, BufferedWriter bw)
	{
		Collections.sort(student, new Comparator<Student>(){
			@Override
			public int compare(Student student1, Student student2)
			{
				return student1.getLastName().compareTo(student2.getLastName());
			}
		});

		System.out.println("Twins:");
		int p = 0;
		for(int i = 0; i<student.size(); i++)
		{

			if(p<student.size()-1)
			{
				p = i+1;
			}
			while(student.get(i).getLastName().equals(student.get(p).getLastName())==true)
			{
				if(student.get(i).getBirthDay() == student.get(p).getBirthDay() && student.get(i).getBirthMonth() == student.get(p).getBirthMonth() && student.get(i).getBirthYear() == student.get(p).getBirthYear()&& student.get(i).getFirstName() != student.get(p).getFirstName())
				{
					System.out.println(student.get(i).getFirstName() + " " +student.get(i).getLastName());
					System.out.println(student.get(p).getFirstName() + " " +student.get(p).getLastName());
					System.out.println();

					Write(student.get(i).getFirstName() + " " +student.get(i).getLastName(), bw);
					Write(" & ", bw);
					Write(student.get(p).getFirstName() + " " +student.get(p).getLastName() + "<br>", bw);

				}

				if(p<student.size()-1)
				{
					p++;
				}
				else
				{
					break;

				}
			}
		}


	}
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 3) Same birth month, print all students that were born in the same month
	 */
	public static void SameBirthMonth(ArrayList<Student> student, BufferedWriter bw)
	{

		String[] months = new String[]{"Janurary", "Feburary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

		System.out.println("Please enter in the month that you would like to see which students have a birthday in.");
		System.out.println("(Press 1 for Janurary, 2 for Feburary, 3 for March . . . .)");
		Scanner read = new Scanner(System.in);
		int BirthMonth = read.nextInt();
		for(int i = 0; i<student.size(); i ++)
		{
			if(student.get(i).getBirthMonth() == BirthMonth){
				System.out.println(student.get(i).getFirstName() + " " + student.get(i).getLastName());
				Write(student.get(i).getFirstName() + " " + student.get(i).getLastName()+ "<br>", bw);
			}
		}
		Write("<br>", bw);
	}
	
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 4) Prints students in the same house
	 */
	public static void SimilarHouse(ArrayList<Student> student, BufferedWriter bw)
	{
		System.out.println("Please enter in a house with the format Last Name/Last Name or First Name Last Name.  (Please also ensure that the first letter of each name is capitalized.)");
		Scanner read = new Scanner(System.in);
		String houseAdvisor = read.nextLine();
		for(int i = 0; i<student.size(); i++)
		{
			if(student.get(i).getAdvisorName().contains(houseAdvisor) == true)
			{
				System.out.println(student.get(i).getFirstName() + " " + student.get(i).getLastName());
				Write(student.get(i).getFirstName() + " " + student.get(i).getLastName()+"<br>", bw);
			}
		}
	}
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 5) Alphabetized list of students in data set by last name, only print last name
	 * 
	 */
	public static void SortedByLastName(ArrayList<Student> student, BufferedWriter bw)
	{

		Collections.sort(student, new Comparator<Student>(){
			@Override
			public int compare(Student student1, Student student2)
			{
				return student1.getLastName().compareTo(student2.getLastName());
			}
		});
		for(int i = 0; i<student.size(); i++)
		{
			System.out.println(student.get(i).getLastName());
			Write(student.get(i).getLastName()+"<br>", bw);
		}
	}
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 6) Print total number of males and females in data set
	 */
	public static void NumberOfMalesAndFemales(ArrayList<Student> student, BufferedWriter bw)
	{
		int males = 0;
		int females = 0;
		for(int i= 0; i<student.size(); i++)
		{

			if(student.get(i).getSexCode().contains("F") == true)
			{
				females ++;
			}
			if(student.get(i).getSexCode().contains("M")== true)
			{
				males ++;
			}
		}
		System.out.println("number of males: " + males);
		System.out.println("number of females: " + females);
		Write("number of males: " + males +"<br>", bw);
		Write("number of females: " + females+"<br>", bw);


	}
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 7) Compare number of students in 2 diff grades
	 */
	public static void WhichGradeIn(ArrayList<Student> student, BufferedWriter bw)
	{
		//Get it so that
		Scanner read = new Scanner(System.in);
		System.out.println("Please enter the first grade (4-12) you would like to compare");
		String firstGradeString = read.nextLine();
		System.out.println("Please enter the second grade(4-12) you would like to compare");
		String secondGradeString = read.nextLine();
		int firstGradeCount = 0;
		int secondGradeCount = 0;
		try{
			if(Integer.parseInt(firstGradeString) != 4&& Integer.parseInt(firstGradeString)!= 5&&Integer.parseInt(firstGradeString) != 6&&Integer.parseInt(firstGradeString) != 7&&Integer.parseInt(firstGradeString) != 8&&Integer.parseInt(firstGradeString) != 9&&Integer.parseInt(firstGradeString) != 10&&Integer.parseInt(firstGradeString) !=11&&Integer.parseInt(firstGradeString) != 12)
			{
				System.out.println("That was an invalid input");
				return;
			}
			if(Integer.parseInt(secondGradeString) != 4&& Integer.parseInt(secondGradeString) != 5&&Integer.parseInt(secondGradeString) != 6&&Integer.parseInt(secondGradeString) != 7&&Integer.parseInt(secondGradeString) != 8&&Integer.parseInt(secondGradeString) != 9&&Integer.parseInt(secondGradeString) != 10&&Integer.parseInt(secondGradeString) !=11&&Integer.parseInt(secondGradeString) != 12)
			{
				System.out.println("That was an invalid input");
				return;
			}
		}
		catch(Exception e)
		{
			System.out.println("That was not a valid input");
			return;
		}
		int  firstGrade = Integer.parseInt(firstGradeString);
		int secondGrade = Integer.parseInt(secondGradeString);
		for(int i = 0; i< student.size(); i++)
		{
			if(student.get(i).getCurrentGrade() == firstGrade)
			{
				firstGradeCount ++;
			}

			if(student.get(i).getCurrentGrade() == secondGrade) //Catch K's
			{
				secondGradeCount ++;
			}


		}
		System.out.println("Number of Kids in " + firstGrade +": "+ firstGradeCount);
		System.out.println("Number of Kids in " + secondGrade +": "+ secondGradeCount);
		Write("Number of Kids in " + firstGrade +": "+ firstGradeCount + "<br>", bw);
		Write("Number of Kids in " + secondGrade +": "+ secondGradeCount + "<br>", bw);

	}
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 8) Students born in 2001
	 */
	public static void StudentsBornIn2001(ArrayList<Student> student, BufferedWriter bw)
	{
		for(int i = 0; i<student.size();i++)
		{
			if(student.get(i).getBirthYear() == 2001)
			{
				System.out.println(student.get(i).getFirstName() + " " + student.get(i).getLastName());
				Write(student.get(i).getFirstName() + " " + student.get(i).getLastName() + "<br>", bw);
			}
		}
	}
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 9) part 1, Only does first name frequency
	 */
	public static void FirstNameFrequency(ArrayList<Student> student, BufferedWriter bw)
	{
		Collections.sort(student, new Comparator<Student>(){
			@Override
			public int compare(Student student1, Student student2)
			{
				return student1.getFirstName().compareTo(student2.getFirstName());
			}
		});
		String firstName[] = new String[student.size()];
		int firstNameFrequency[] = new int[student.size()];
		int q =0;
		for(int i = 0; i<student.size(); i++)
		{
			if(i == 0)
			{
				firstName[q] = student.get(i).getFirstName();
				firstNameFrequency[q] ++;
			}
			if(student.get(i).getFirstName().equals(firstName[q]))
			{
				firstNameFrequency[q] ++;
			}
			else{
				q++;
				firstName[q] = student.get(i).getFirstName();
				firstNameFrequency[q] ++;
			}
		}

		int Max = 0;
		int Counter = 0;
		int space = 0;
		int freqFound = 0;
		for(int p = 0; p<10; p++)
		{
			for(int m = 0; m<firstNameFrequency.length;m++)
			{
				Counter =Counter + firstNameFrequency[m];
				if(firstNameFrequency[m]>Max)
				{
					Max = firstNameFrequency[m];
					freqFound = m;
					space  = Counter;
				}
			}
			int ForOutput = p+1;

			System.out.println("The "+ ForOutput +" most common name is: " + firstName[freqFound] + " with " + firstNameFrequency[freqFound] + " students");
			Write("The "+ ForOutput +" most common name is: " + firstName[freqFound] + " with " + firstNameFrequency[freqFound] + " counts <br>", bw);
			firstNameFrequency[freqFound] = 0;
			Max = 0;
			freqFound = 0;
			space = 0;
			Counter = 0;
		}
		try {
			Thread.sleep(10);               
		} catch(InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}
	
	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 9) part 2, last name frequency
	 */
	public static void LastNameFrequency(ArrayList<Student> student, BufferedWriter bw)
	{
		Collections.sort(student, new Comparator<Student>(){
			@Override
			public int compare(Student student1, Student student2)
			{
				return student1.getLastName().compareTo(student2.getLastName());
			}
		});

		String LastName[] = new String[student.size()];
		int LastNameFrequency[] = new int[student.size()];
		int q =0;
		for(int i = 0; i<student.size(); i++)
		{
			if(i == 0)
			{
				LastName[q] = student.get(i).getLastName();
				LastNameFrequency[q] ++;
			}
			if(student.get(i).getLastName().equals(LastName[q]))
			{
				LastNameFrequency[q] ++;
			}
			else{
				q++;
				LastName[q] = student.get(i).getLastName();
				LastNameFrequency[q] ++;
			}
		}
		int Max = 0;
		int Counter = 0;
		int space = 0;
		int freqFound = 0;
		for(int p = 0; p<10; p++)
		{
			for(int m = 0; m<LastNameFrequency.length;m++)
			{
				Counter =Counter + LastNameFrequency[m];
				if(LastNameFrequency[m]>Max)
				{
					Max = LastNameFrequency[m];
					freqFound = m;
					space  = Counter;
				}
			}
			int ForOutput = p+1;

			System.out.println("The "+ ForOutput +" most common name is: " + LastName[freqFound] + " with " + LastNameFrequency[freqFound] + " counts");
			Write("The "+ ForOutput +" most common name is: " + LastName[freqFound] + " with " + LastNameFrequency[freqFound] + " counts <br>", bw);
			LastNameFrequency[freqFound] = 0;
			Max = 0;
			freqFound = 0;
			space = 0;
			Counter = 0;
		}
	}

	/**
	 * 
	 * @param student
	 * @param bw
	 * 
	 * 10) Students by grade 
	 */
	public static void StudentsByGrade(ArrayList<Student> student, BufferedWriter bw)
	{
		for(int i = 0; i<9; i++)
		{
			int gradeOn = i +4;
			System.out.println("Students in Grade " + gradeOn+":");
			for(int q = 0; q<student.size(); q++)
			{
				if(student.get(q).getCurrentGrade() == gradeOn)
				{
					System.out.println(student.get(q).getFirstName() + " " + student.get(q).getLastName());
					Write(student.get(q).getFirstName() + " " + student.get(q).getLastName()+"<br>", bw);
				}
			}
			System.out.println();
			Write("<br>", bw);

		}
	}
	/**
	 * 
	 * @param content
	 * @param bw
	 * 
	 * Write to output location
	 */
	public static void Write(String content, BufferedWriter bw)
	{
		try{
			bw.write(content);
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
	
}//close